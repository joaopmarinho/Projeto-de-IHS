LIMITE = 120
LIMITE_VERT = 29
#usar o layout de console x = 120 e y = 30

LIMITE_PERDER = 10

PONTOS_ACERTO = 100
PONTOS_ERRO = 5