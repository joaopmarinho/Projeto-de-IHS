# e é uma tupla (A,B) representando os coeficientes da RETA A*x + B
def solve1(A, B, x):
    return A*x + B

# e é uma tupla (A,B,C) representando os coeficientes da PARABOLA A*x**2 + B*x + C
def solve2(A, B, C, x):
    return A*x**2 + B*x + C

