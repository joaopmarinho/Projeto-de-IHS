# Como executar

Será preciso executar o arquivo `jogoMain.py`. Comando:

```console
$ python jogoMain.py
```
